const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..');
const server=require('http').createServer((req,res)=>{let n=decodeURIComponent(req.url.split('?')[0]);if(n.endsWith('/'))n+='index.html';try{let b=fs.readFileSync(path.join(root,n));res.setHeader('Content-Type',({'.js':'text/javascript','.css':'text/css','.html':'text/html','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.svg':'image/svg+xml','.json':'application/json'})[path.extname(n)]||'application/octet-stream');res.end(b)}catch(e){res.statusCode=404;res.end('missing')}});
(async()=>{
await new Promise(r=>server.listen(8794,'127.0.0.1',r));
const browser=await chromium.launch({headless:true,executablePath:path.join(root,'browser-runtime/chromium'),args:require('../browser-tools/node_modules/@sparticuz/chromium/build/index.js').default.args});
const ctx=await browser.newContext({viewport:{width:412,height:915},deviceScaleFactor:2,isMobile:true,hasTouch:true});
await ctx.addInitScript(()=>{
 let seed=712003;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};localStorage.setItem('rookSoundTurn','0');
 window.__study={armed:false,frozen:false,blocked:[],humanClicks:0};
 const st=window.setTimeout.bind(window),si=window.setInterval.bind(window);
 function ready(){try{return window.__study.armed&&game?.phase==='play'&&game.trick?.length===4}catch{return false}}
 function freeze(){if(ready()&&!window.__study.frozen){window.__study.frozen=true;window.__study.trick=JSON.parse(JSON.stringify(game.trick));window.__study.me=myIndex;window.__study.players=players.map(p=>({name:p.name,team:p.team,isBot:p.isBot}));window.__study.trump=game.trump;window.__study.ledColor=game.ledColor;window.__study.frozenAt=performance.now()}}
 window.setTimeout=(fn,delay,...args)=>{freeze();return st(()=>{freeze();if(window.__study.frozen){window.__study.blocked.push({delay,fn:String(fn).slice(0,240)});return;}if(typeof fn==='function')fn(...args);else (0,eval)(fn)},delay)};
 window.setInterval=(fn,delay,...args)=>si(()=>{freeze();if(!window.__study.frozen)fn(...args)},delay);
});
const p=await ctx.newPage();const errors=[];p.on('pageerror',e=>errors.push(e.message));await p.route('https://cdn.jsdelivr.net/**',r=>r.abort());
try{
 await p.goto('http://127.0.0.1:8794/recovered_review/candidate003/',{waitUntil:'networkidle'});await p.locator('#hor-player-name').fill('Jerome Griff');await p.locator('#soloPracticeBtn').click();if(await p.locator('#tutorialSkip').isVisible())await p.locator('#tutorialSkip').click();await p.locator('#bidPlus').waitFor({state:'visible'});await p.locator('#bidPassBtn').click();await p.locator('#scoreSpeed701 button').filter({hasText:'MAX'}).click();
 const start=Date.now();while(Date.now()-start<60000){
  const s=await p.evaluate(()=>({phase:game.phase,turn:game.currentPlayer,me:myIndex,resolving:game.resolvingTrick,frozen:window.__study.frozen}));
  if(s.frozen)break;
  if(s.phase==='bidding'&&await p.locator('#bidPassBtn').isVisible())await p.locator('#bidPassBtn').click();
  if(s.phase==='play'){
   await p.evaluate(()=>window.__study.armed=true);
   if(s.turn===s.me&&!s.resolving){const c=p.locator('#myHand .card-face.playable').first();if(await c.count()){await c.click({timeout:1000});await p.evaluate(()=>window.__study.humanClicks++);}}
  }
  await p.waitForTimeout(20);
 }
 await p.waitForTimeout(400);
 await p.evaluate(()=>{window.__pausedAnimations=document.getAnimations().map(a=>({target:a.effect?.target?.id||a.effect?.target?.className,time:a.currentTime}));document.getAnimations().forEach(a=>a.pause());});
 const result=await p.evaluate(()=>({study:window.__study,state:{phase:game.phase,trick:game.trick,resolving:game.resolvingTrick,capturing:!!window._trickCapturing,flight:window._trickFlightKey,hands:game.hands.map(h=>h.length)},html:document.querySelector('#trickArea').outerHTML,cards:[...document.querySelectorAll('#trickArea .card-face')].map(e=>{let b=e.getBoundingClientRect();return {id:e.dataset.id,rect:{x:b.x,y:b.y,w:b.width,h:b.height},transform:getComputedStyle(e).transform,wrap:e.parentElement.outerHTML}})}));
 if(!result.study.frozen||result.state.trick.length!==4||result.state.capturing)throw Error('No legitimate pre-collection four-card state');
 fs.mkdirSync(path.join(__dirname,'toss-evidence'),{recursive:true});
 result.errors=errors;
 const expected=['red-1','red-11','red-5','red-13'];
 if(JSON.stringify(result.cards.map(c=>c.id))!==JSON.stringify(expected))throw Error('Trick differs from accepted four-card state');
 fs.writeFileSync(path.join(__dirname,'toss-evidence/original-state.json'),JSON.stringify(result,null,2));
 await p.screenshot({path:path.join(__dirname,'toss-evidence/original-stack.png')});
 await p.evaluate(()=>{
  window.__protected=[...document.querySelectorAll('body *')].filter(e=>!e.closest('#trickArea')).map(e=>({e,rect:e.getBoundingClientRect().toJSON()}));window.__clipEls=[];window.__clipAudit=[];let anc=document.querySelector('#trickArea .trick-stack');while(anc&&anc!==document.body){window.__clipEls.push(anc);const cs=getComputedStyle(anc);window.__clipAudit.push({tag:anc.tagName,id:anc.id,class:anc.className,overflow:cs.overflow,contain:cs.contain,clip:cs.clipPath,transform:cs.transform,rect:anc.getBoundingClientRect().toJSON(),style:anc.getAttribute('style')});if(cs.contain.includes('paint')||cs.contain==='content'||cs.contain==='strict')anc.style.setProperty('contain','layout style','important');anc=anc.parentElement;}
  window.__nodes=[...document.querySelectorAll('#trickArea .trick-card-wrap')];
  window.__saved=window.__nodes.map(w=>({style:w.getAttribute('style'),html:w.innerHTML}));
  const coords=[[115,438],[207,370],[299,438],[207,506]];
  window.__coords=coords;
  window.__nodes.forEach((w,i)=>{
   const card=w.querySelector('.card-face');const r=card.getBoundingClientRect();
   w.style.setProperty('transform','none','important');w.style.setProperty('transition','none','important');w.style.setProperty('animation','none','important');
   const anchor=w.getBoundingClientRect();
   w.style.setProperty('transform',`translate(${coords[i][0]-anchor.x-44}px,${coords[i][1]-anchor.y-63}px)`,'important');
   const inner=document.createElement('div');inner.className='harness-plane';inner.style.cssText='width:88px;height:126px;transform-origin:44px 63px;';
   card.before(inner);const orientation=document.createElement('div');orientation.className='toss-orientation';orientation.style.cssText='width:88px;height:126px;transform-origin:44px 63px;';inner.append(orientation);const sizing=document.createElement('div');sizing.className='study-size';sizing.style.cssText='position:relative;width:88px;height:126px;transform-origin:44px 63px;';orientation.append(sizing);sizing.append(card);for(const [x,y] of [[44,63],[0,0],[88,0],[88,126],[0,126]]){const probe=document.createElement('span');probe.className='study-probe';probe.style.cssText=`position:absolute;left:${x}px;top:${y}px;width:0;height:0;pointer-events:none;`;sizing.append(probe);}window.__saved[i].baseAnchor=[anchor.x+44,anchor.y+63];window.__saved[i].card=card;
  });
 });
 const lockedMatrices=JSON.parse(fs.readFileSync(path.join(root,'recovered_review/variants/variant-evidence.json'))).find(v=>v.spec.name==='E-plane-derived').cards.map(c=>c.matrix);
 const lockedE={lambda:.70,k:.00115,oldReference:[207,438],reference:[207,353],landingTranslation:[0,-85]};
 const specs=[
 {name:'A-current-0pct',scale:1,cards:[[141,386,100],[211,342,175],[286,400,-98],[202,424,9]]},
 {name:'B-smaller-5pct',scale:.95,cards:[[141,386,100],[211,342,175],[286,400,-98],[202,424,9]]},
 {name:'C-smaller-10pct',scale:.90,cards:[[141,386,100],[211,342,175],[286,400,-98],[202,424,9]]},
 {name:'D-smaller-15pct',scale:.85,cards:[[141,386,100],[211,342,175],[286,400,-98],[202,424,9]]}
 ];
 fs.writeFileSync(path.join(__dirname,'toss-evidence/clip-audit.json'),JSON.stringify(await p.evaluate(()=>window.__clipAudit),null,2));
 async function apply(spec,reference){
  await p.evaluate(({spec,reference,lockedE,lockedMatrices})=>{
   window.__coords=spec.cards.map(a=>a.slice(0,2));
   window.__nodes.forEach((w,i)=>{
    const [cx,cy,rotation]=spec.cards[i];
    const anchor=window.__saved[i].baseAnchor;
    w.style.setProperty('transform',`translate(${cx-anchor[0]}px,${cy-anchor[1]}px)`,'important');
    w.querySelector('.harness-plane').style.transform=lockedMatrices[i];
    w.querySelector('.toss-orientation').style.transform=`rotate(${rotation}deg)`;w.querySelector('.study-size').style.transform=`scale(${spec.scale})`;
   });
  },{spec,reference,lockedE,lockedMatrices});
 }
 const evidence=[];
 for(const spec of specs){
  await apply(spec,lockedE.reference);await p.waitForTimeout(150);
  const ev=await p.evaluate(()=>({trick:game.trick,capturing:!!window._trickCapturing,cards:window.__nodes.map((w,i)=>{const c=w.querySelector('.card-face'),r=c.getBoundingClientRect();return {seat:['Dagger/left','Cinder/top','Crow/right','Jerome/bottom'][i],id:c.dataset.id,anchor:window.__coords[i],width:c.offsetWidth,height:c.offsetHeight,scale:w.querySelector('.study-size').style.transform,projectedPoints:[...w.querySelectorAll('.study-probe')].map(e=>{const q=e.getBoundingClientRect();return [q.x,q.y]}),rect:{x:r.x,y:r.y,w:r.width,h:r.height},matrix:w.querySelector('.harness-plane').style.transform,rotation:w.querySelector('.toss-orientation').style.transform,outerPositionTransform:w.style.transform,zIndex:getComputedStyle(w).zIndex,shadow:getComputedStyle(c).boxShadow,html:c.outerHTML}})}));
  evidence.push({spec,...ev});
  await p.screenshot({path:path.join(__dirname,'toss-evidence/'+spec.name+'.png')});
 }
 fs.writeFileSync(path.join(__dirname,'toss-evidence/variant-evidence.json'),JSON.stringify(evidence,null,2));
 const parity=await p.evaluate(()=>({checked:window.__protected.length,changes:window.__protected.map(({e,rect},i)=>({i,id:e.id,class:e.className,before:rect,after:e.getBoundingClientRect().toJSON()})).filter(x=>JSON.stringify(x.before)!==JSON.stringify(x.after))}));
 fs.writeFileSync(path.join(__dirname,'toss-evidence/geometry-parity.json'),JSON.stringify(parity,null,2));
 await p.evaluate(()=>{window.__nodes.forEach((w,i)=>{const inner=w.querySelector('.harness-plane');inner.before(window.__saved[i].card);inner.remove();w.setAttribute('style',window.__saved[i].style);});window.__clipEls.forEach((e,i)=>{const s=window.__clipAudit[i].style;if(s===null)e.removeAttribute('style');else e.setAttribute('style',s);});});
 await p.waitForTimeout(400);
 const restored=await p.evaluate(()=>({html:document.querySelector('#trickArea').outerHTML,trick:game.trick}));
 fs.writeFileSync(path.join(__dirname,'toss-evidence/restoration.json'),JSON.stringify({htmlIdentical:restored.html===result.html,trickIdentical:JSON.stringify(restored.trick)===JSON.stringify(result.state.trick),parity},null,2));
 await p.screenshot({path:path.join(__dirname,'toss-evidence/restored-stack.png')});
 console.log(JSON.stringify({tossVariants:evidence.length,parity,restoredHTML:restored.html===result.html}));
}catch(e){console.error(e);process.exitCode=1}
await browser.close();server.close();
})();
