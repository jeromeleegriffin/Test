# 93 — POST BRAIN C RECOVERY HANDOFF 2026-10-05

Status: EVIDENCE ONLY. Owner handoff preserved verbatim so a future assistant can see the instruction that produced Brain D.
This file is not itself a pixel authority.

GROK — GRIFFIN HOUSE OF ROOKS
MASTER BRAIN DURABLE RECOVERY UPDATE
POST-BRAIN-C / 2026-10-05

============================================================
OWNER / PURPOSE
============================================================

Owner:
Jerome Griffin

This is a CONTROLLED MASTER BRAIN DOCUMENTATION / AUTHORITY UPDATE.

The purpose is to make the externally stored Griffin House Master Brain
on GitHub/live storage sufficiently complete that the project can be
recovered even if ChatGPT conversation memory disappears.

THIS IS NOT GAME DEVELOPMENT.

THIS IS NOT A GAME BUILD.

THIS IS NOT A DEPLOYMENT OF R712 OR ANY SUCCESSOR.

THIS IS NOT AUTHORIZATION TO REDESIGN ANYTHING.

Do not modify the game merely to satisfy this task.

The external Master Brain should become a durable recovery point from
which a fresh Zoey/ChatGPT could determine:

- what Griffin House of Rooks is
- who owns/directs it
- who Zoey, Mark and Grok are
- what is currently authoritative
- what is locked
- what is protected
- what is approved but not implemented
- what is experimental
- what is superseded
- what failed and why
- what actual runtime evidence exists
- what must not be regenerated
- how Jerome expects the project to be operated
- what work remains for later
- which visual references govern which dimensions
- which source/runtime artifacts override generated imagery

The goal is:

IF CHATGPT MEMORY DISAPPEARED TOMORROW,
THE EXTERNAL MASTER BRAIN SHOULD BE ENOUGH TO RECONSTRUCT
THE PROJECT'S CURRENT INTENT, AUTHORITIES, PROTECTION RULES,
AND WORKING METHOD WITHOUT STARTING OVER.

============================================================
FIRST — AUDIT BEFORE WRITING
============================================================

Before changing anything:

1. Locate the current external Griffin House Master Brain.
2. Identify:
   - current.json or equivalent current pointer
   - current published Brain version
   - frozen Master Brain C backup
   - manifest/index
   - visual-authority folders
   - runtime/source evidence
   - protected asset masters
   - project rules / owner decisions
   - hashes/manifests if present
3. Read the existing material.
4. Determine which information below is ALREADY present.
5. Do NOT create unnecessary duplicates.
6. Do NOT silently overwrite historical authorities.
7. Preserve the frozen Brain C backup unchanged.
8. Preserve history and supersession relationships.

If an item below already exists accurately and completely:

KEEP IT.

If it exists but is incomplete:

UPDATE THE NEW CANDIDATE BRAIN COPY, preserving history.

If the actual authoritative source file is unavailable:

DO NOT INVENT IT.

Document the missing source and STOP that individual addition rather
than substituting a visually similar file.

============================================================
CRITICAL PUBLICATION RULE
============================================================

DO NOT modify the current/live Master Brain in-place as the first step.

Build and verify a NEW isolated Master Brain candidate/version.

The previous Master Brain C must remain frozen and recoverable.

Only after:

- content audit
- file audit
- exact diff review
- manifest validation
- authority validation
- link/path validation
- hash validation where applicable

may the new Master Brain version become current.

UPDATE current.json / latest / equivalent pointer LAST.

There must always be a recoverable prior authority.

============================================================
AUTHORITY STATUS VOCABULARY
============================================================

Every important artifact or decision must carry an explicit status.

Use a consistent vocabulary such as:

CURRENT AUTHORITY
LOCKED
PROTECTED BASELINE
APPROVED — BANKED — NOT IMPLEMENTED
EXPERIMENTAL
EVIDENCE ONLY
SUPERSEDED
REJECTED
PENDING VERIFICATION

Do not allow an attractive experiment to appear equivalent to a
runtime authority.

Do not allow a planned design to appear implemented.

Do not allow generated imagery to silently become gameplay authority.

============================================================
TEAM / RESPONSIBILITY MODEL
============================================================

Preserve this operating model:

JEROME
Owner / Director / final decision authority.

ZOEY
Main ChatGPT / project brain / design and project reasoning partner /
reviewer.

MARK
ChatGPT Work.
Used for substantial project work, runtime/browser investigation,
multi-step file investigation, controlled implementation, verification,
packaging and other work better suited to a full working environment.

GROK
GitHub/code/publishing/deployment side.
Use for repository operations and externally publishing approved
project material, within the exact authorized scope.

Do not interchange these roles casually.

============================================================
JEROME'S COMMUNICATION / COMMAND RULES
============================================================

Preserve these rules for future assistants.

GENERATE / GEN
Explicit authorization to generate an image.

Image generation is otherwise LOCKED.

ROLL
Means modify/build project files.
It does NOT mean generate an image.

BANK
Means preserve the approved decision/artifact in durable project
authority storage, not merely remember it conversationally.

OK / CONTINUE
Current convention: proceed automatically through the already agreed
scope rather than stopping for routine progress updates.

However:

OK / CONTINUE does NOT by itself authorize:
- production deployment
- destructive operations
- promotion of an experimental candidate to authority
- changing a protected baseline
- changing scope

Those require the applicable explicit authorization.

NEW PROMPT/HANDOFF RULE:

Before Zoey writes a substantive handoff/prompt for Mark or Grok,
Zoey should first discuss the intended contents with Jerome and ask
whether he wants anything added.

Do not jump immediately from discussion into issuing a handoff prompt
unless Jerome has indicated the contents are ready.

Once Jerome approves the contents, produce the final prompt.

COPY/PASTE RULE:

When Zoey provides text intended to be copied/pasted elsewhere,
put ALL intended copy/paste text inside ONE clearly copyable fenced
code block.

============================================================
CORE PROJECT OPERATING RULES
============================================================

Preserve these prominently.

BANK BEFORE RISK.

IF THE PIXELS EXIST, USE THE PIXELS.

ACTUAL PIXELS > RECREATED APPROXIMATIONS.

THE WORKING SCREEN WINS.

TRUST THE DIFF.

SURGICAL HANDS, WIDE-ANGLE EYES.

PLAY FIRST → DISCOVER LATER.

THE PHYSICAL ART ADAPTS AROUND THE GAME.
THE GAME DOES NOT ADAPT AROUND THE ART.

THE TABLE MUST BLOCK THE PEOPLE.
THE TABLE MUST NOT BLOCK THE GAME.

FAILED FIX RULE:

REMOVE
→ RESTORE
→ REDIAGNOSE
→ REPLACE

Never layer another patch on top of a failed patch.

LIVE GAME:
PROTECT / MAINTAIN.

ISOLATED PROTOTYPE:
INVENT / EXPERIMENT.

An experiment does not become game authority merely because it looks
good.

It earns integration only after review and verification.

============================================================
EVIDENCE / CLAIM DISCIPLINE
============================================================

Do not claim:

- runtime success without runtime evidence
- physical-phone success without physical-phone evidence
- deployment without deployment evidence
- approval without Jerome's approval
- authority without explicit promotion
- a file exists without verifying it
- exact geometry without actual measured evidence
- an experiment is production

Source inspection is not automatically equivalent to runtime
verification.

Where physical-device verification is required, preserve that
distinction.

============================================================
PROTECTED RUNTIME BASELINE
============================================================

R712 is the protected clean runtime baseline unless a later explicitly
approved authority supersedes it.

Do NOT modify R712 during this Master Brain update.

Do NOT create a new game revision merely for documentation.

Do NOT modify:

- gameplay
- bidding
- scoring
- bots
- cards
- Bid Box
- Bid Dock
- speed engine
- landscape
- production player
- service worker
- browser/player data

This task is documentation/reference synchronization only.

============================================================
TABLE-003 — CURRENT PHYSICAL TABLE AUTHORITY
============================================================

TABLE-003 has passed final calibration and is LOCKED as the physical
table direction.

Preserve the final approved table/environment visual authority and the
real-runtime evidence used to validate it.

The TABLE-003 physical direction includes:

- seated-player viewpoint
- broad substantial premium walnut near rail
- strong natural foreshortening
- near end visually wider than far end
- convincing natural side-rail convergence
- tapered/narrower far end
- deep blue felt
- physically believable rail thickness
- recessed felt
- substantial furniture mass
- warm luxury dark-wood library
- fireplace shifted RIGHT rather than centered behind the far player
- mountain landscape above fireplace in the approved visual direction
- black raven artwork/portrait on left where applicable
- polished floor
- premium warm lighting
- ZERO CHAIRS

Do not recenter the fireplace merely to align it with Cinder.

TABLE SEAT GEOMETRY and ROOM GEOMETRY are separate concerns.

The final calibration specifically preserved the substantial near wood
rather than thinning it merely to chase perspective.

The final result passed.

Do not continue micro-calibrating TABLE-003 without new owner
authorization.

============================================================
TABLE-003 FILES TO PRESERVE / SYNC
============================================================

Ensure the external Brain contains the appropriate approved authority
files, including the final physical-table authority.

Known current ChatGPT Master Brain authority:

TABLE003_MASTER_TABLE_DESIGN_AUTHORITY_2026-10-05.png

Also preserve the recovered real-runtime comparison/source:

TABLE003_FINAL_CALIBRATION_VS_AUTHORITY_SOURCE_2026-10-05.png

This recovered comparison is especially important because:

LEFT:
FINAL CALIBRATION CANDIDATE
Actual real-runtime Bid Box capture

RIGHT:
MASTER TABLE DESIGN AUTHORITY
environment/table reference

The LEFT runtime side remains authority for actual game pixels.

The RIGHT generated/environment side is NOT authority for game UI.

If a superseded TABLE-003 reference remains in history, mark it
SUPERSEDED rather than silently deleting history.

============================================================
CARD SCALE IS NOT LOCKED BY TABLE-003
============================================================

Record explicitly:

Approval of TABLE-003 did NOT lock final card size.

Card scale/readability is a separate future design decision.

Do not infer final card size from the generated table authority.

============================================================
SCENE-INTEGRATED SEATED PLAYER AUTHORITY
============================================================

Add/sync the newly approved player-construction visual authority:

SCENE_INTEGRATED_SEATED_PLAYER_MASTER_REFERENCE_2026-10-05.png

Add/sync the detailed written construction authority:

SCENE_INTEGRATED_SEATED_PLAYER_MASTER_CONSTRUCTION_AUTHORITY_2026-10-05.txt

These are expensive-to-rediscover knowledge and must be treated as
durable project authority.

============================================================
WHAT THE SEATED-PLAYER IMAGE IS AUTHORITY FOR
============================================================

It is authority for:

- physical player integration
- seated illusion
- depth relationship
- body/table occlusion
- upper-body crop
- perspective-aware player scale
- borderless character treatment
- environmental integration
- intentional rail interaction

It is NOT authority for:

- card values
- card count
- card arrangement
- card geometry
- gameplay state
- Bid Box geometry
- Bid Dock geometry
- score geometry
- runtime UI geometry
- exact table geometry
- exact room geometry

For those dimensions:

REAL RUNTIME / LOCKED TABLE AUTHORITY WINS.

============================================================
PLAYER CONSTRUCTION — HARD-WON RULES
============================================================

Preserve these explicitly.

The desired result is not merely:

"BORDERLESS AVATARS."

The actual design direction is:

SCENE-INTEGRATED SEATED CHARACTERS.

Cinder, Dagger and Crow should feel like real people physically seated
around the table.

No visible avatar container.

No circle.

No oval.

No rectangle.

No shield.

No medallion.

No ornate portrait frame.

Natural alpha silhouette is the avatar boundary.

ZERO VISIBLE CHAIRS.

The unseen chair/lower body should be inferred from:

- pose
- table occlusion
- scale
- arm interaction
- perspective

============================================================
AUTHORITATIVE PLAYER/TABLE DEPTH STACK
============================================================

Preserve this conceptual construction model:

LAYER 0
Room/background.

LAYER 1
Seated character torsos/shoulders.

LAYER 2
Authoritative physical table rail/apron occlusion.

LAYER 3
Only intentionally foregrounded hands/forearms resting ON TOP of the
rail.

LAYER 4
Felt/play surface.

LAYER 5
Legitimate played cards/game objects.

LAYER 6
Necessary game UI.

CORE DISTINCTION:

THE TABLE MUST BLOCK THE PEOPLE.

THE TABLE MUST NOT BLOCK THE GAME.

============================================================
TABLE RAIL = HARD CHARACTER OCCLUDER
============================================================

The wooden table rail is an AUTHORITATIVE OCCLUSION MASK for
character bodies.

Character torso/clothing/body pixels do NOT have permission to pass
through the wooden rail or appear on the felt.

No:

- torso penetration
- clothing penetration
- shoulder penetration
- waist penetration
- accidental arm penetration
- ghost body pixels
- transparency through the rail
- feathering through the rail
- body painted onto felt

If a body conflicts with the rail:

THE RAIL WINS.

Hide more of the body if necessary.

Do NOT move/redesign the table to accommodate the character.

============================================================
FOREGROUND ARM/HAND EXCEPTION
============================================================

A deliberately separated hand or forearm MAY come forward and rest
physically ON TOP OF the wooden rail.

This is a deliberate foreground limb.

It must:

- approach the rail naturally
- make believable physical contact
- rest on the top surface
- not emerge through the side of the wood
- not pass through the wood
- not accidentally invade the felt

Crow's successful forearm treatment is the reference concept.

============================================================
DAGGER — PRESERVE THE FAILURE LESSON
============================================================

Dagger repeatedly failed in earlier visual experiments because his
torso/clothing penetrated the left wooden rail and appeared inside the
table.

Do NOT rediscover this failure.

For Dagger:

The inside edge of the LEFT wooden rail is an absolute character-body
clipping boundary.

Torso/chest/clothing/lower shoulder/waist/background arm portions stay
behind the rail.

If necessary, show LESS Dagger rather than violating the table.

This failure history is important implementation knowledge.

============================================================
CROW — PRESERVE THE SUCCESS
============================================================

Crow demonstrated the successful physical relationship:

TORSO BEHIND TABLE
+
OPTIONAL FOREARM/HAND NATURALLY RESTING ON TOP OF RAIL.

This treatment made Crow appear physically seated rather than pasted
onto the interface.

Preserve that concept.

============================================================
CINDER — FAR SEAT
============================================================

Cinder belongs to the far/top TABLE SEAT.

She is NOT positioned according to fireplace center.

She should naturally appear somewhat smaller because of perspective.

Head + shoulders + upper chest / limited torso.

Lower body disappears behind far rail.

Do not float her over the table.

Do not place her on the felt.

Do not move the fireplace to accommodate her.

============================================================
BOTTOM HUMAN PLAYER
============================================================

There is NO bottom/Jerome avatar in the new physical player direction.

The human player is represented by:

- first-person seated camera
- bottom hand/cards
- player interaction

Do not create a fourth seated character at the bottom.

============================================================
PLAYER EDGE / LIGHTING TREATMENT
============================================================

Use restrained environmental integration.

Where needed:

- approximately 1–2 physical-phone-pixel perceptual dark separation
- dark charcoal/brown-black
- adaptive rather than uniform
- stronger only where dark hair/clothing crosses dark background

Use:

- restrained room/fireplace rim light where physically appropriate
- tight soft contact/depth shadow

Do NOT use:

- cartoon outlines
- continuous orange halos
- neon glow
- magical particles
- giant drop shadows
- sticker treatment

============================================================
REMOVE "YOUR PARTNER" — NEXT ROLL
============================================================

Preserve this approved owner decision:

On the next authorized Griffin House of Rooks roll, remove the visible:

YOUR PARTNER

presentation label.

Reason:

The partner relationship is already visually understandable and the
label is unnecessary clutter.

This is PRESENTATION ONLY.

Do NOT alter partner gameplay/logic.

Do NOT leave:

- empty placeholder
- reserved gap
- ghost text
- pseudo-element
- stale runtime element

Bid Box/Bid Dock remain untouched.

Status:

APPROVED — BANKED — NOT YET IMPLEMENTED
unless a later verified build supersedes this status.

============================================================
PLAYER POSITIONING STATUS
============================================================

Record explicitly:

The historical protected R712 player/avatar/name coordinates are
baseline/runtime evidence.

They are NOT automatically the final TABLE-003 seated-character
positions.

The new physical TABLE-003 requires later player-seat calibration.

Important seating relationships:

Cinder:
far/top table seat.

Dagger:
left physical seat relationship.

Crow:
right physical seat relationship.

Jerome:
first-person bottom seat; no visible avatar.

Do not blindly copy old circular-avatar coordinates into the final
scene-integrated character implementation.

Preserve old coordinates as evidence because they remain useful for
comparison/recovery.

============================================================
HISTORICAL PROTECTED GEOMETRY EVIDENCE
============================================================

Audit whether the external Brain already contains the recovered
geometry.

If not, preserve the measured evidence, clearly labeled as historical
protected R712/baseline geometry rather than guaranteed final
TABLE-003 seating.

Known evidence includes:

TABLE:
.table
L36.8
T107.4
R323.2
B542.32
W286.4
H434.93

.table-felt
L28.8
T97
R331.2
B551.12
W302.4
H454.12

TOP/PARTNER AVATAR:
#slot-partner .seat-avatar
L137.11
T120.85
W80
H80
historical gameplay transform approximately (0, -5.12)

BOTTOM/ME AVATAR:
#slot-me .seat-avatar
L135.97
T430.90
W80
H80
historical gameplay transform approximately (0, +4.8)

LEFT:
L10.76
T271.61
W75.2
H75.2
historical gameplay transform approximately (-33.8391, 0)

RIGHT:
L274.04
T271.61
W75.2
H75.2
historical gameplay transform approximately (+33.8391, 0)

TOP NAME:
final approximately
L93.2
T125.65
W201.6
H81.91
delta approximately X -10 / Y +15

BOTTOM NAME:
final approximately
L90.2
T424.51
W201.6
H81.91
delta approximately X -13 / Y +25

These values are preservation/recovery evidence.

Do NOT reinterpret them as final scene-integrated seated-character
geometry.

============================================================
LAYOUT MAPPER KNOWLEDGE
============================================================

Preserve the existence and purpose of the custom Griffin House layout
mapper.

Important controls/functions include:

PICK
PARENT
CHILD
MOVE
RESIZE
STEP
RESET
DONE
MORE
dockable/draggable panel

Important persistence lesson:

Export/import must preserve enough information to reconstruct layout,
including:

- selector
- X/Y
- width/height
- scale
- original rect
- final rect
- inline styles

Historical storage key observed:

ghc611LayoutV2

Also preserve:

- unhide-all concept
- lock-all concept
- snap lines
- copy-value/snap behavior

Do not rebuild the mapper merely for this documentation update.

============================================================
SPEED CONTROL — APPROVED DIRECTION
============================================================

Preserve:

Exactly ONE permanent speed control in the compact header beside the
Griffin/Raven score.

Buttons:

1× | 3× | MAX

Remove/avoid duplicate menu speed controls.

Historical verified engine evidence:

1× approximately 104 seconds
3× approximately 37 seconds
MAX approximately 11 seconds

These are historical runtime measurements, not a promise that every
future build will produce identical timing.

============================================================
BID BOX / BID DOCK PROTECTION
============================================================

Preserve prominently:

DO NOT TOUCH BID DOCK / BID BOX unless Jerome explicitly authorizes
work on it.

Table/avatar/card experiments do not implicitly authorize Bid Box
changes.

============================================================
LAST TRICK / LAST 3 UX
============================================================

Preserve the approved future UX direction.

Current visible portrait Last 3 pill is eventually to be removed.

In portrait:

After a completed trick clears, the EMPTY CENTER TRICK AREA becomes
the interaction.

Tap the center:
temporarily restore/show the immediately previous completed trick.

Tap again or outside:
dismiss it.

Use a restrained one-time discovery hint after an early completed
trick so new players can discover the feature.

Do not make the visible Last 3 pill the permanent solution.

Status:

APPROVED — BANKED — NOT IMPLEMENTED
unless later verified evidence supersedes it.

============================================================
FOUR-CARD PLAYED-CARD PERSPECTIVE PROJECT
============================================================

Preserve the REQUIREMENT and STATUS without falsely promoting an
unfinished experiment.

Hard evaluation requirement:

A complete four-card trick must be visible simultaneously:

1. Jerome/bottom played card
2. Cinder/partner/top played card
3. left opponent played card
4. right opponent played card

Do not evaluate physical perspective primarily from a single center
card.

If normal gameplay clears the trick too quickly:

Use an ISOLATED visual harness/freeze of a legitimate four-card state.

Do NOT modify production gameplay timing merely to capture a
screenshot.

Played center/trick cards should visually agree with:

- felt plane
- table perspective
- seat direction
- trick center
- seated-player camera

This is NOT card redesign.

Do not change:

- card identity
- values
- colors
- artwork
- player hand
- opponent backs
- sorting
- Nest
- gameplay

Preserve any existing four-card visibility-gate package as:

EVIDENCE / EXPERIMENTAL

unless it has separately earned authority.

Do not label it completed merely because the requirement is banked.

============================================================
CARD / DECK IDENTITY
============================================================

Audit whether the external Brain already contains the actual approved
card masters and their hashes/manifest.

If they exist:

KEEP THEM.

Do not duplicate unnecessarily.

If approved individual card masters are missing and authoritative
copies are available, preserve them.

The deck identity is ROOK:

GREEN
RED
YELLOW
BLACK
+
special bird/Rook card as applicable.

NEVER silently substitute:

hearts
diamonds
clubs
spades
generic poker cards
generic casino cards

Approved exact card artwork must not be regenerated simply because an
AI can create something similar.

If the pixels exist:

USE THE PIXELS.

============================================================
FUTURE PREMIUM CARD DESIGN PRINCIPLES
============================================================

Preserve separately from existing card masters.

Card redesign work must begin with actual geometry/readability audit.

Priority hierarchy:

1. gameplay readability
2. touch usability
3. value/color recognition
4. consistency
5. premium appearance
6. believable physical relationship
7. literal real-world scale LAST

Different card contexts may legitimately use different display scales.

The table can be physically believable while cards use readability
cheats.

Do not sacrifice usability to literal physical scale.

============================================================
NEST DESIGN AUTHORITY
============================================================

Preserve the approved future Nest direction.

Working concept:

GRIFFIN HOUSE NEST TRAY

Physical table-integrated presentation.

Dark leather/felt recessed tray with restrained antique brass/gold
treatment.

Use SIX REAL Nest cards.

Use the authoritative premium card renderer.

The presentation/container follows the cards.

THE CARDS DO NOT GET SACRIFICED TO FIT AN ARBITRARY CONTAINER.

Six cards do NOT have to be one tiny row.

They may:

- fan
- overlap
- stagger
- use 3+3
- use another readable premium arrangement

Readability wins over literal physical scale.

Approved flow concept:

WIN BID
→ NEST ARRIVES
→ VIEW SIX REAL CARDS
→ FULL HAND / DISCARD SELECTION
→ CONFIRM / RETURN CARDS
→ TRUMP SELECTION IN SAME PRESENTATION
→ TRAY CLEARS
→ NORMAL PLAY

Status:

APPROVED DESIGN DIRECTION — NOT IMPLEMENTED
unless later verified evidence supersedes it.

============================================================
NEW-PLAYER EXPERIENCE PRINCIPLE
============================================================

Preserve:

PLAY FIRST → DISCOVER LATER.

New users should reach the table/game quickly.

Avoid freezing a new player behind excessive initial controls.

Advanced settings can be discovered later.

Training-hand direction was disliked.

Bots are the default/easy entry.

Leave Room must remain available at all levels where applicable.

============================================================
PROGRESSION / XP OWNER DECISION
============================================================

Preserve the approved future principle:

XP / House Level should eventually be visible on the table.

When XP/House Levels are enabled for everyone:

perform legacy migration/credit ONCE using retained local statistics
where possible.

Prevent double-credit.

Present retrospective awards appropriately.

Do not implement merely because this documentation records the
decision.

============================================================
APPROVED SPINNER ROTATION
============================================================

Preserve these exact seven names for later rotation:

1. Rook Card Flip
2. Griffin Gold Sweep
3. Rook Flight
4. Crest Build
5. Card Shuffle Swirl
6. Wing Sweep
7. Ring Draw

Do not rename them casually.

Status:
BANKED FUTURE DESIGN.

============================================================
OTHER BANKED PRESENTATION DECISIONS
============================================================

Preserve where not already present:

- Win page should use actual team names rather than generic A/B.
- Biggest Tricks page direction: show only the two biggest with
  animation; Griffin icon opacity reduced approximately 15%.
- Message Table removed.
- Trump stamp is text only:
  RED / BLACK / GREEN / YELLOW.
- No unnecessary extra trump bar.
- Bid stepper duplicate-number issue/history should not be
  reintroduced.
- Existing card sorting behavior is protected unless explicitly
  authorized.

Do not implement these merely as part of this documentation sync.

============================================================
MARK AUTHORIZATION RULE
============================================================

Preserve the workflow clarification:

When Jerome gives Mark an explicitly scoped implementation handoff,
Mark may generate/edit/create assets INSIDE that exact authorized
scope where required to complete the task.

This does NOT grant Mark general permission to redesign unrelated
parts of the project.

Scope boundaries remain binding.

============================================================
PRODUCTION / EXPERIMENT SEPARATION
============================================================

Preserve:

Production is OFF LIMITS for experiments.

Use isolated candidates/tests.

Do not clear Jerome's physical-phone data or service worker merely to
run an experiment.

Do not disturb preserved physical-phone/browser evidence.

Do not use production as a disposable test harness.

============================================================
CURRENT PLAYER / PROMOTION DISCIPLINE
============================================================

Preserve the principle:

An isolated candidate does not automatically become Current Player.

Promotion requires explicit approval and verification.

Current/latest pointers should change only after the candidate has
earned authority.

For Master Brain publication:

CURRENT POINTER CHANGES LAST.

For game publication:

do not deploy/promote without explicit authorization.

============================================================
FROZEN HISTORY
============================================================

Master Brain C must remain recoverable and unchanged as historical
authority.

The new Master Brain version should clearly state that it supersedes
Brain C as CURRENT only after successful verification/publication.

Do not erase Brain C.

Do not rewrite history.

============================================================
CREATE A FRESH-START RECOVERY DOCUMENT
============================================================

This is an important addition.

Create a concise but comprehensive READ-FIRST recovery document in the
new Master Brain.

Suggested concept/name:

00_READ_FIRST_GRIFFIN_HOUSE_RECOVERY.md

or an equivalent existing naming convention if the Brain already has
one.

It must tell a completely fresh Zoey/assistant:

1. Who Jerome is in the project.
2. Who Zoey, Mark and Grok are.
3. Which Brain version is current.
4. What the protected runtime baseline is.
5. Which table authority is current.
6. Which player/avatar authority is current.
7. Which artifacts are real-runtime authority.
8. Which generated images are visual/reference authority only.
9. Which major items are banked but not implemented.
10. Which items are experimental/pending.
11. What absolutely must not be touched without authorization.
12. The core workflow rules.
13. Where the authority index/manifest lives.
14. What to read next before performing work.

The document should be useful if the reader has ZERO prior ChatGPT
memory.

============================================================
CREATE / UPDATE AUTHORITY INDEX
============================================================

Create or update a human-readable authority index/manifest.

For every major authority include:

- exact filename
- path
- date
- status
- authority scope
- what it is NOT authority for
- supersedes
- superseded by, where applicable
- hash where practical
- related runtime evidence
- related written specification

Examples:

TABLE003_MASTER_TABLE_DESIGN_AUTHORITY_2026-10-05.png
STATUS: CURRENT AUTHORITY
SCOPE: physical table/environment design
NOT AUTHORITY FOR: runtime UI/cards

SCENE_INTEGRATED_SEATED_PLAYER_MASTER_REFERENCE_2026-10-05.png
STATUS: CURRENT PLAYER-CONSTRUCTION VISUAL AUTHORITY
SCOPE: seated-character physical integration
NOT AUTHORITY FOR: cards/UI/table geometry/gameplay state

SCENE_INTEGRATED_SEATED_PLAYER_MASTER_CONSTRUCTION_AUTHORITY_2026-10-05.txt
STATUS: CURRENT PLAYER-CONSTRUCTION WRITTEN AUTHORITY
SCOPE: layer/occlusion/build rules

TABLE003_FINAL_CALIBRATION_VS_AUTHORITY_SOURCE_2026-10-05.png
STATUS: RUNTIME/COMPARISON EVIDENCE
SCOPE: actual real-runtime TABLE-003 calibration evidence and
authority distinction

============================================================
HASH / INTEGRITY REQUIREMENTS
============================================================

Where practical:

Calculate SHA-256 for newly added authority files.

Record hashes in the manifest/index.

Do not claim byte identity without computing it.

For copied assets, verify that the external copy matches the supplied
source.

============================================================
DO NOT COPY FAILED GENERATED EXPERIMENTS AS AUTHORITIES
============================================================

We created several failed avatar/table mockups while discovering the
correct construction.

Do NOT promote those failed images.

Their lessons may be preserved in prose.

The expensive lesson matters.

The failed visual does not need to become an authority.

In particular preserve the lesson:

Dagger repeatedly penetrated the left table rail until the table rail
was treated as an authoritative occlusion mask.

That lesson belongs in the Brain.

The failed images themselves need not become current authority.

============================================================
DO NOT CONFUSE VISUAL AUTHORITY WITH RUNTIME AUTHORITY
============================================================

This distinction must be prominent throughout the Brain.

REAL RUNTIME SCREEN:
authority for actual game pixels.

LOCKED TABLE VISUAL:
authority for physical table/environment direction.

SEATED PLAYER VISUAL:
authority for player construction/depth relationship.

WRITTEN CONSTRUCTION SPEC:
authority for implementation rules.

PLANNED UX DOCUMENT:
authority for approved future intent, NOT evidence of implementation.

EXPERIMENT:
evidence/research only until promoted.

============================================================
NO UNAUTHORIZED CHANGES
============================================================

Do NOT:

- modify R712
- create R713 merely for this
- modify production game files
- change table geometry
- change player geometry
- change Bid Box
- change Bid Dock
- change cards
- change sorting
- change scoring
- change bots
- change landscape
- deploy a game
- modify service workers
- modify physical-phone state
- rewrite frozen Brain C
- delete historical authorities
- silently replace assets
- invent missing files
- promote unfinished experiments
- alter current pointer before verification

============================================================
BUILD THE NEW MASTER BRAIN CANDIDATE
============================================================

After the audit:

1. Start from the current verified Master Brain.
2. Create an isolated NEW candidate/version.
3. Integrate the missing durable information above.
4. Copy/sync only authoritative source files that are actually
   available.
5. Preserve existing good material.
6. Add explicit statuses.
7. Add/update READ-FIRST recovery document.
8. Add/update authority index.
9. Add hashes.
10. Preserve supersession/history.
11. Produce exact diff from previous Brain C/current authority.

============================================================
VERIFY BEFORE PUBLICATION
============================================================

Verify:

- all expected files exist
- filenames exact
- paths correct
- images open
- text files open
- READ-FIRST document opens
- authority index opens
- hashes correspond
- no broken references
- no accidental duplicate authorities
- Brain C frozen copy unchanged
- no game/runtime files changed
- no R712 changes
- no unrelated repository changes
- no current pointer changed prematurely

============================================================
PUBLICATION ORDER
============================================================

Only after verification:

1. Publish the NEW Master Brain version.
2. Verify it from the externally accessible location.
3. Verify READ-FIRST.
4. Verify authority index.
5. Verify key images/text authorities.
6. Verify hashes/diffs.
7. ONLY THEN update current.json / latest pointer to the new Brain.

If external verification fails:

DO NOT advance the current pointer.

============================================================
RETURN TO JEROME / ZOEY
============================================================

Return:

1. Exact new Master Brain version/name.
2. Exact repository/live path.
3. Commit SHA.
4. Previous Brain version preserved.
5. Confirmation Brain C remains unchanged/frozen.
6. Exact list of added files.
7. Exact list of modified documentation/index files.
8. Exact diff summary.
9. SHA-256 list for new authorities.
10. READ-FIRST path.
11. Authority-index path.
12. Current-pointer change, if performed.
13. Confirmation current pointer was changed LAST.
14. Confirmation R712/game files were untouched.
15. Confirmation no unrelated files changed.
16. Any requested source that was unavailable and therefore NOT
    invented/substituted.
17. Any contradictions discovered between old Brain material and this
    handoff that require Jerome's decision.

============================================================
FINAL PRINCIPLE
============================================================

This update is successful only if a fresh future Zoey can open the
external Master Brain with no conversational memory and correctly
understand:

WHAT IS REAL.
WHAT IS LOCKED.
WHAT IS PROTECTED.
WHAT IS PLANNED.
WHAT FAILED.
WHAT REMAINS.
AND HOW JEROME EXPECTS THE PROJECT TO BE HANDLED.

BANK THE KNOWLEDGE.
PRESERVE THE EVIDENCE.
PROTECT THE GAME.
TRUST THE DIFF.