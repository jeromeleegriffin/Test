# AUTHORITY INDEX — MASTER BRAIN E
Updated: 2026-10-05
Supersedes Brain D as current only after pointer publication.
Brain D and Brain C remain frozen.

Status vocabulary:
LOCKED, BANKED, PROTECTED, NOT IMPLEMENTED, NOT DEPLOYED, NEXT AUTHORIZED ROLL, PENDING VERIFICATION, EVIDENCE ONLY, SUPERSEDED, REJECTED.

Visual authority is not runtime authority.
Actual pixels / actual photos trump code.

## Current written authority

| File | Status | Scope | Not authority for |
| --- | --- | --- | --- |
| 01_MASTER_BANK/GRIFFIN_HOUSE_MASTER_BRAIN_CHECKPOINT_2026-10-05.txt | CURRENT CHECKPOINT | 2026-10-05 recovery state | missing pixels; deployment proof |
| 01_MASTER_BANK/TABLE003_FINAL_PLAYED_CARD_PRESENTATION_AUTHORITY_2026-10-05.txt | LOCKED VISUAL PRESENTATION / NOT IMPLEMENTED / NOT DEPLOYED | played-card size, perspective, toss, orientations | Bid Box; production |
| 01_MASTER_BANK/CARD_ASSET_PLAN_2026-10-05.txt | BANKED / NOT IMPLEMENTED | future premium card system | current faces |
| 01_MASTER_BANK/SCENE_INTEGRATED_SEATED_PLAYER_MASTER_CONSTRUCTION_AUTHORITY_2026-10-05.txt | LOCKED CONSTRUCTION | seated-player layering | missing visual master |
| 01_MASTER_BANK/NEXT_ROLL_REMOVE_YOUR_PARTNER_2026-10-05.txt | NEXT AUTHORIZED ROLL / NOT IMPLEMENTED | visible label only | partner logic |
| 01_MASTER_BANK/ACTUAL_PIXELS_OVERRIDE_CODE_RULE_2026-10-05.txt | CURRENT PROCESS | pixels beat code | inventing missing pixels |
| 01_MASTER_BANK/MARK_RETURN_PACKAGE_ZIP_ONLY_RULE_2026-10-05.txt | CURRENT PROCESS | Mark delivery | game changes |
| 01_MASTER_BANK/NEW_CHAT_MASTER_BRAIN_STARTUP_RULE_2026-10-05.txt | CURRENT PROCESS | fresh chat | skipping the Brain |
| 01_MASTER_BANK/GRIFFIN_HOUSE_NEW_CHAT_HANDOFF_2026-10-05.txt | CURRENT HANDOFF | next Zoey | substitute for the Brain |
| MASTER_BANK.md section 31 | CURRENT WRITTEN ADDITION | E delta | replacement of frozen D |

## Pending verification — not invented

| Named file | Intended status | Why absent |
| --- | --- | --- |
| TABLE003_MASTER_TABLE_DESIGN_AUTHORITY_2026-10-05.png | CURRENT TABLE VISUAL once supplied | not in sync attachment |
| TABLE003_FINAL_CALIBRATION_VS_AUTHORITY_SOURCE_2026-10-05.png | RUNTIME COMPARISON once supplied | not in sync attachment |
| SCENE_INTEGRATED_SEATED_PLAYER_MASTER_REFERENCE_2026-10-05.png | PLAYER VISUAL once supplied | not in sync attachment |
| GRIFFIN_HOUSE_TABLE003_PLAYED_CARD_SIZE_STUDY_REVIEW.zip | SIZE-STUDY EVIDENCE once supplied | not in sync attachment |

## Retained from D/C
Brain C and Brain D visual references remain in this package with their prior labels.
They are historical or supporting. They are not substitutes for the missing 2026-10-05 masters.
